
function assemble(){
    exports.SimpleMessage = 'Hello world';
}
assemble()
